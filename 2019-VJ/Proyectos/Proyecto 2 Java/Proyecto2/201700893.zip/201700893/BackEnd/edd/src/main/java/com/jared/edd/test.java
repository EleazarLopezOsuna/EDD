package com.jared.edd;

import com.jared.edd.estructuras.*;

public class test {
	public static ListaDestino destinito = new ListaDestino();
	public static GrafoRuta rutitas = new GrafoRuta();
	public static MatrizRuta matrisita = new MatrizRuta();
	public static TablaHash tablita = new TablaHash();
	public static ArbolB arbolito = new ArbolB();
}
